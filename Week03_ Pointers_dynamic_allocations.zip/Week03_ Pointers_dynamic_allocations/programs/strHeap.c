#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* repeated  (char*  original, int n);

int main(void) {
  
    

	char mystring[] = "bon";
    
	char *str = repeated(mystring, 3);
    
	printf("%s\n", str);
   
	free(str); 

    
	return 0;


}

char* repeated  (char*  original, int n) {
	int i, length = strlen(original);
        char*  newString = malloc (sizeof(char) * length * n + 1);
	char*  helper = newString;

	for (i = 0; i < n; i++) {
		strcpy( helper, original);
		helper = helper + length;	
	}
	return newString;
}


