#include <stdio.h>
#include<stdlib.h>

#define SIZE 4

int* returnArray();

int main(void) {

	int  i;

	int* arr = returnArray();

	for (i=0; i<SIZE; i++)
		printf("%d ", arr[i]);

	return 0;
}

int* returnArray() {
	
	int i;

	int *a = malloc(sizeof(int) * SIZE);

	if (a != NULL) {
	
		for (i=0; i<SIZE; i++)
			a[i] = i + 1;
        }
	return a;
}

